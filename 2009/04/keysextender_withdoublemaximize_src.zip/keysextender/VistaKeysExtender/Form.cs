﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Windows.Forms;
using VistaKeysExtender.Properties;
using VistaKeysExtender.WinApi;

namespace VistaKeysExtender
{
    public partial class Form : System.Windows.Forms.Form
    {
        #region User Interface

        private bool IsLoaded { get; set;}

        private readonly IntPtr _currentHandle;

        public Form(bool showNotifyIcon)
        {
            InitializeComponent();

            notifyIcon.Visible = showNotifyIcon;
            _currentHandle = GetCurrent();

            RegisterHotKeys();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            lblVersion.Text = string.Format("v. {0}", Assembly.GetExecutingAssembly().GetName().Version);
            LoadData();
        }

        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);

            if (!IsLoaded)
            {
                IsLoaded = true;
                Hide();
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void linkMail_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start(linkMail.Text);
        }

        private void notifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Show();
            Activate();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            Hide();
            SaveData();
            MessageBox.Show(this, "Restart application to take affect.", "Keys Extenders");
        }

        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show();
            Activate();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Hide();
            LoadData();
        }

        private void checkBoxMEnabled_CheckedChanged(object sender, EventArgs e)
        {
            UpdateStatusMovedControls();
        }

        private void enableDoubleMaximizeCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateStatusMaximizeControls();
        }

        private void UpdateStatusMovedControls()
        {
            label7.Enabled =
                numericUpDownmStep.Enabled =
                checkBoxMAlt.Enabled =
                checkBoxMCtrl.Enabled =
                checkBoxMShift.Enabled = label6.Enabled = label5.Enabled = checkBoxMEnabled.Checked;
        }

        private void checkBoxAEnabled_CheckedChanged(object sender, EventArgs e)
        {
            UpdateStatusAttachedControls();
        }

        private void UpdateStatusAttachedControls()
        {
            checkBoxAAlt.Enabled =
                checkBoxACtrl.Enabled =
                checkBoxAShift.Enabled = label3.Enabled = label4.Enabled = checkBoxAEnabled.Checked;
        }

        private void UpdateStatusMaximizeControls()
        {
            initialMaximizeWidthTextBox.Enabled = enableDoubleMaximizeCheckBox.Checked;
            initialMaximizeHeightTextBox.Enabled = enableDoubleMaximizeCheckBox.Checked;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start(linkLabel1.Text);
        }

        #endregion

        #region Settings Data

        private void LoadData()
        {
            checkBoxAEnabled.Checked = Settings.Default.WindowsAttachedEnable;
            checkBoxMEnabled.Checked = Settings.Default.WindowsMoveEnable;
            checkBoxAAlt.Checked = Settings.Default.WindowsAttachedAlt;
            checkBoxAShift.Checked = Settings.Default.WindowsAttachedShift;
            checkBoxACtrl.Checked = Settings.Default.WindowsAttachedCtrl;
            checkBoxMAlt.Checked = Settings.Default.WindowsMoveAlt;
            checkBoxMShift.Checked = Settings.Default.WindowsMoveShift;
            checkBoxMCtrl.Checked = Settings.Default.WindowsMoveCtrl;
            numericUpDownmStep.Value = Settings.Default.WindowsMoveStep;

            enableDoubleMaximizeCheckBox.Checked = Settings.Default.EnableDoubleMaximize;
            initialMaximizeWidthTextBox.Text = Settings.Default.InitialMaximizeWidth.ToString();
            initialMaximizeHeightTextBox.Text = Settings.Default.InitialMaximizeHeight.ToString();

            UpdateStatusMovedControls();
            UpdateStatusAttachedControls();
            UpdateStatusMaximizeControls();
        }

        private void SaveData()
        {
            Settings.Default.WindowsAttachedEnable = checkBoxAEnabled.Checked;
            Settings.Default.WindowsMoveEnable = checkBoxMEnabled.Checked;
            Settings.Default.WindowsAttachedAlt = checkBoxAAlt.Checked;
            Settings.Default.WindowsAttachedShift = checkBoxAShift.Checked;
            Settings.Default.WindowsAttachedCtrl = checkBoxACtrl.Checked;
            Settings.Default.WindowsMoveAlt = checkBoxMAlt.Checked;
            Settings.Default.WindowsMoveShift = checkBoxMShift.Checked;
            Settings.Default.WindowsMoveCtrl = checkBoxMCtrl.Checked;
            Settings.Default.WindowsMoveStep = (int)numericUpDownmStep.Value;

            Settings.Default.EnableDoubleMaximize = enableDoubleMaximizeCheckBox.Checked;
            Settings.Default.InitialMaximizeWidth = Int32.Parse(initialMaximizeWidthTextBox.Text);
            Settings.Default.InitialMaximizeHeight = Int32.Parse(initialMaximizeHeightTextBox.Text);

            Settings.Default.Save();
        }

        #endregion

        #region Hot keys 

        private readonly Keys[] _keys = new[] { Keys.Left, Keys.Right, Keys.Up, Keys.Down };

        private readonly IList<HotKey> _hotKeys = new List<HotKey>();

        private void RegisterHotKeys()
        {
            if (Settings.Default.WindowsAttachedEnable)
                RegisterAttached();
            if (Settings.Default.WindowsMoveEnable)
                RegisterMoved();
        }

        private void RegisterAttached()
        {
            HotKey.KeyModifiers modifiers = HotKey.KeyModifiers.Windows |
                                            (Settings.Default.WindowsAttachedAlt
                                                 ? HotKey.KeyModifiers.Alt
                                                 : HotKey.KeyModifiers.None) |
                                            (Settings.Default.WindowsAttachedCtrl
                                                 ? HotKey.KeyModifiers.Control
                                                 : HotKey.KeyModifiers.None) |
                                            (Settings.Default.WindowsAttachedShift
                                                 ? HotKey.KeyModifiers.Shift
                                                 : HotKey.KeyModifiers.None);
            Register(modifiers);
        }

        private void RegisterMoved()
        {
            HotKey.KeyModifiers modifiers = HotKey.KeyModifiers.Windows |
                                            (Settings.Default.WindowsMoveAlt
                                                 ? HotKey.KeyModifiers.Alt
                                                 : HotKey.KeyModifiers.None) |
                                            (Settings.Default.WindowsMoveCtrl
                                                 ? HotKey.KeyModifiers.Control
                                                 : HotKey.KeyModifiers.None) |
                                            (Settings.Default.WindowsMoveShift
                                                 ? HotKey.KeyModifiers.Shift
                                                 : HotKey.KeyModifiers.None);
            Register(modifiers);
        }

        private void Register(HotKey.KeyModifiers modifiers)
        {
            foreach (Keys key in _keys)
            {
                try
                {
                    HotKey hotKey = new HotKey
                    {
                        Key = key,
                        KeyModifier = modifiers,
                        Handle = _currentHandle
                    };
                    hotKey.HotKeyPressed += HotKeyPressed;
                    _hotKeys.Add(hotKey);
                }
                catch
                {
                    MessageBox.Show(this,
                                    string.Format(
                                        "Cannot register this hot key '{0} + {1}', maybe already registered by another process.",
                                        modifiers, key), "Keys Extenders");
                }
            }
        }

        private static IntPtr GetCurrent()
        {
            using (Process curProcess = Process.GetCurrentProcess())
            using (ProcessModule curModule = curProcess.MainModule)
            {
                if (curModule != null) return curModule.BaseAddress;
            }
            return IntPtr.Zero;
        }

        static void HotKeyPressed(object sender, KeyEventArgs e)
        {
            if (Settings.Default.WindowsAttachedAlt == e.Alt
                    && Settings.Default.WindowsAttachedCtrl == e.Control
                    && Settings.Default.WindowsAttachedShift == e.Shift)
                SetWindowLocation(e.KeyCode);
            else if (Settings.Default.WindowsMoveAlt == e.Alt
                    && Settings.Default.WindowsMoveCtrl == e.Control
                    && Settings.Default.WindowsMoveShift == e.Shift)
                MoveWindow(e.KeyCode);
        }

        #endregion

        #region Windows moved

        private static Dictionary<IntPtr, WAWindows.Rect> oldRects = 
            new Dictionary<IntPtr, WAWindows.Rect>();

        enum WinState
        {
            Normal,
            Minimized,
            Left,
            Right,
            Maximized
        }

        private static WinState GetWindowState(Screen screen, WAWindows.Rect rect)
        {
            if (rect.Width >= screen.WorkingArea.Width && rect.Height >= screen.WorkingArea.Height) // Maximized
                return WinState.Maximized;
            if (rect.Top < -screen.WorkingArea.Height && rect.Left < -screen.WorkingArea.Width)
                return WinState.Minimized;

            if (rect.Height >= screen.WorkingArea.Height && Math.Abs(rect.Width - (screen.WorkingArea.Width/2)) <= 1)
            {
                if (rect.Left == screen.WorkingArea.Left)
                    return WinState.Left;
                else
                    return WinState.Right;
            }

            return WinState.Normal;
        }

        private static void SetWindowLocation(Keys k)
        {
            //Active Window
            IntPtr window = WAWindows.GetForegroundWindow();
            // Check SIZEBOX Style (Window can sizable)
            if (((Int64)WAWindows.GetWindowLongPtr(window, WAWindows.GwlStyle) & WAWindows.WsSizebox)
                == WAWindows.WsSizebox)
            {
                
                WAWindows.Rect rect, rectDesktop;
                if (WAWindows.GetWindowRect(window, out rect)
                     && WAWindows.GetWindowRect(WAWindows.GetDesktopWindow(), out rectDesktop))
                {
                    Screen screen = Screen.FromHandle(window);
                    WinState state = GetWindowState(screen, rect);

                    if (k == Keys.Left && state == WinState.Right || k == Keys.Right && state == WinState.Left)
                    {
                        WAWindows.ShowWindow(window, (int)WAWindows.WindowShowStyle.ShowNormal);
                        return;
                    }

                    if (k == Keys.Down)
                    {
                        if (state == WinState.Maximized || state == WinState.Left || state == WinState.Right)
                            WAWindows.ShowWindow(window, (int)WAWindows.WindowShowStyle.ShowNormal);
                        else
                        {
                            if (Settings.Default.EnableDoubleMaximize)
                            {
                                if (oldRects.ContainsKey(window))
                                {
                                    var oldRect = oldRects[window];

                                    WAWindows.SetWindowPos(window, WAWindows.HwndTop,
                                                           oldRect.Left,
                                                           oldRect.Top,
                                                           oldRect.Width, oldRect.Height, WAWindows.SwpShowWindow);

                                    oldRects.Remove(window);
                                }
                                else
                                {
                                    WAWindows.ShowWindow(window, (int)WAWindows.WindowShowStyle.ShowMinimized);
                                }
                            }
                            else
                            {
                                WAWindows.ShowWindow(window, (int)WAWindows.WindowShowStyle.ShowMinimized);
                            }
                        }

                    }
                    else if (k == Keys.Up)
                    {
                        if (state == WinState.Minimized)
                            WAWindows.ShowWindow(window, (int)WAWindows.WindowShowStyle.Restore);
                        else
                        {
                            if (WAWindows.GetWindowRect(window, out rect))
                            {
                                if (Settings.Default.EnableDoubleMaximize)
                                {
                                    int maxWidth = Settings.Default.InitialMaximizeWidth;
                                    int maxHeight = Settings.Default.InitialMaximizeHeight;

                                    if (rect.Width >= (maxWidth - 1) && rect.Height >= (maxHeight - 1))
                                    {
                                        WAWindows.ShowWindow(window, (int)WAWindows.WindowShowStyle.ShowMaximized);

                                        WAWindows.SetWindowPos(window, WAWindows.HwndTop,
                                                           screen.WorkingArea.Left,
                                                           screen.WorkingArea.Top,
                                                           screen.WorkingArea.Width, screen.WorkingArea.Height, WAWindows.SwpShowWindow);
                                    }
                                    else
                                    {
                                        int left = rect.Left;
                                        int top = rect.Top;
                                        int width = rect.Width;
                                        int height = rect.Height;

                                        if (top + maxHeight > screen.WorkingArea.Height)
                                            top = screen.WorkingArea.Height - maxHeight;
                                        if (left + maxWidth > screen.WorkingArea.Width)
                                            left = screen.WorkingArea.Width - maxWidth;

                                        if (width < maxWidth)
                                            width = maxWidth;
                                        if (height < maxHeight)
                                            height = maxHeight;

                                        WAWindows.SetWindowPos(window, WAWindows.HwndTop,
                                                           left,
                                                           top,
                                                           width, height, WAWindows.SwpShowWindow);

                                        if (oldRects.ContainsKey(window))
                                            oldRects[window] = rect;
                                        else
                                            oldRects.Add(window, rect);
                                    }
                                }
                                else
                                {
                                    WAWindows.ShowWindow(window, (int)WAWindows.WindowShowStyle.ShowMaximized);

                                    WAWindows.SetWindowPos(window, WAWindows.HwndTop,
                                                       screen.WorkingArea.Left,
                                                       screen.WorkingArea.Top,
                                                       screen.WorkingArea.Width, screen.WorkingArea.Height, WAWindows.SwpShowWindow);
                                }
                            }
                        }
                    }
                    else
                    {
                        if (k == Keys.Left)
                        {
                            rect.Left = screen.WorkingArea.Left;
                            rect.Right = screen.WorkingArea.Right - screen.WorkingArea.Width/2;
                        }
                        else if (k == Keys.Right)
                        {
                            rect.Left = screen.WorkingArea.Right - screen.WorkingArea.Width/2;
                            rect.Right = screen.WorkingArea.Right;
                        }

                        WAWindows.ShowWindow(window, (int) WAWindows.WindowShowStyle.ShowMaximized);
                        WAWindows.SetWindowPos(window, WAWindows.HwndTop, rect.Left, screen.WorkingArea.Top,
                                               rect.Width, screen.WorkingArea.Bottom, WAWindows.SwpShowWindow);
                    }
                }
            }
        }

        private static void MoveWindow(Keys keys)
        {
            int moveStep = Settings.Default.WindowsMoveStep;
            //Active Window
            IntPtr window = WAWindows.GetForegroundWindow();
            WAWindows.Rect rect, rectDesktop;
            if (WAWindows.GetWindowRect(window, out rect) && WAWindows.GetWindowRect(WAWindows.GetDesktopWindow(), out rectDesktop))
            {
                Screen screen = Screen.FromHandle(window);
                WinState state = GetWindowState(screen, rect);

                if (state == WinState.Normal)
                {
                    if (keys == Keys.Left)
                    {
                        rect.Right -= moveStep;
                        rect.Left -= moveStep;
                    }
                    if (keys == Keys.Right)
                    {
                        rect.Right += moveStep;
                        rect.Left += moveStep;
                    }
                    if (keys == Keys.Up)
                    {
                        rect.Bottom -= moveStep;
                        rect.Top -= moveStep;
                    }
                    if (keys == Keys.Down)
                    {
                        rect.Bottom += moveStep;
                        rect.Top += moveStep;
                    }
                    if (rect.Top < rectDesktop.Bottom && rect.Bottom > 0 && rect.Right > 0 &&
                        rect.Left < rectDesktop.Right)
                        WAWindows.SetWindowPos(window, WAWindows.HwndTop, rect.Left, rect.Top, rect.Width, rect.Height,
                                               WAWindows.SwpShowWindow);
                }
            }
        }

        #endregion
    }
}
