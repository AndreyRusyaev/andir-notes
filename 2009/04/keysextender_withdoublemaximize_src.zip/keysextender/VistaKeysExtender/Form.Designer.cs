﻿namespace VistaKeysExtender
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form));
            this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.showToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.lblVersion = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.linkMail = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.groupBoxAttached = new System.Windows.Forms.GroupBox();
            this.checkBoxAEnabled = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBoxACtrl = new System.Windows.Forms.CheckBox();
            this.checkBoxAShift = new System.Windows.Forms.CheckBox();
            this.checkBoxAAlt = new System.Windows.Forms.CheckBox();
            this.groupBoxMove = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.numericUpDownmStep = new System.Windows.Forms.NumericUpDown();
            this.checkBoxMEnabled = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.checkBoxMCtrl = new System.Windows.Forms.CheckBox();
            this.checkBoxMShift = new System.Windows.Forms.CheckBox();
            this.checkBoxMAlt = new System.Windows.Forms.CheckBox();
            this.windowsMaximizeGroupBox = new System.Windows.Forms.GroupBox();
            this.initialMaximizeHeightTextBox = new System.Windows.Forms.TextBox();
            this.maximizeSizeSeparatorLabel = new System.Windows.Forms.Label();
            this.initialMaximizeWidthTextBox = new System.Windows.Forms.TextBox();
            this.initialSizeLabel = new System.Windows.Forms.Label();
            this.enableDoubleMaximizeCheckBox = new System.Windows.Forms.CheckBox();
            this.contextMenuStrip.SuspendLayout();
            this.groupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBoxAttached.SuspendLayout();
            this.groupBoxMove.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownmStep)).BeginInit();
            this.windowsMaximizeGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // notifyIcon
            // 
            this.notifyIcon.ContextMenuStrip = this.contextMenuStrip;
            this.notifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon.Icon")));
            this.notifyIcon.Text = "Keys Extender (Win 7 Compatible)";
            this.notifyIcon.Visible = true;
            this.notifyIcon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon_MouseDoubleClick);
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(119, 48);
            // 
            // showToolStripMenuItem
            // 
            this.showToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.showToolStripMenuItem.Name = "showToolStripMenuItem";
            this.showToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.showToolStripMenuItem.Text = "Show";
            this.showToolStripMenuItem.Click += new System.EventHandler(this.showToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.closeToolStripMenuItem.Image = global::VistaKeysExtender.Properties.Resources.close;
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // groupBox
            // 
            this.groupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox.Controls.Add(this.linkLabel1);
            this.groupBox.Controls.Add(this.lblVersion);
            this.groupBox.Controls.Add(this.label2);
            this.groupBox.Controls.Add(this.pictureBox1);
            this.groupBox.Controls.Add(this.linkMail);
            this.groupBox.Controls.Add(this.label1);
            this.groupBox.Location = new System.Drawing.Point(12, 12);
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size(573, 116);
            this.groupBox.TabIndex = 5;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "About";
            // 
            // linkLabel1
            // 
            this.linkLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(299, 48);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(261, 17);
            this.linkLabel1.TabIndex = 5;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "http://code.google.com/p/keysextender/";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVersion.Location = new System.Drawing.Point(6, 87);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(42, 17);
            this.lblVersion.TabIndex = 4;
            this.lblVersion.Text = "label3";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(468, 70);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(95, 34);
            this.label2.TabIndex = 3;
            this.label2.Text = "Denis Gladkikh\r\n2009\r\n";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::VistaKeysExtender.Properties.Resources.app;
            this.pictureBox1.Location = new System.Drawing.Point(7, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(34, 32);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // linkMail
            // 
            this.linkMail.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.linkMail.AutoSize = true;
            this.linkMail.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.linkMail.Location = new System.Drawing.Point(363, 31);
            this.linkMail.Name = "linkMail";
            this.linkMail.Size = new System.Drawing.Size(197, 17);
            this.linkMail.TabIndex = 1;
            this.linkMail.TabStop = true;
            this.linkMail.Text = "mailto:outcoldman@gmail.com";
            this.linkMail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkMail_LinkClicked);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(323, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "If you have a question or suggestion:";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(429, 341);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(510, 341);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // groupBoxAttached
            // 
            this.groupBoxAttached.Controls.Add(this.checkBoxAEnabled);
            this.groupBoxAttached.Controls.Add(this.label4);
            this.groupBoxAttached.Controls.Add(this.label3);
            this.groupBoxAttached.Controls.Add(this.checkBoxACtrl);
            this.groupBoxAttached.Controls.Add(this.checkBoxAShift);
            this.groupBoxAttached.Controls.Add(this.checkBoxAAlt);
            this.groupBoxAttached.Location = new System.Drawing.Point(12, 134);
            this.groupBoxAttached.Name = "groupBoxAttached";
            this.groupBoxAttached.Size = new System.Drawing.Size(186, 196);
            this.groupBoxAttached.TabIndex = 0;
            this.groupBoxAttached.TabStop = false;
            this.groupBoxAttached.Text = "Windows Attached";
            // 
            // checkBoxAEnabled
            // 
            this.checkBoxAEnabled.AutoSize = true;
            this.checkBoxAEnabled.Location = new System.Drawing.Point(9, 20);
            this.checkBoxAEnabled.Name = "checkBoxAEnabled";
            this.checkBoxAEnabled.Size = new System.Drawing.Size(78, 21);
            this.checkBoxAEnabled.TabIndex = 0;
            this.checkBoxAEnabled.Text = "Enabled";
            this.checkBoxAEnabled.UseVisualStyleBackColor = true;
            this.checkBoxAEnabled.CheckedChanged += new System.EventHandler(this.checkBoxAEnabled_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(179, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "+ (Up | Down | Right | Left)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Windows Key + ";
            // 
            // checkBoxACtrl
            // 
            this.checkBoxACtrl.AutoSize = true;
            this.checkBoxACtrl.Location = new System.Drawing.Point(9, 102);
            this.checkBoxACtrl.Name = "checkBoxACtrl";
            this.checkBoxACtrl.Size = new System.Drawing.Size(51, 21);
            this.checkBoxACtrl.TabIndex = 2;
            this.checkBoxACtrl.Text = "Ctrl";
            this.checkBoxACtrl.UseVisualStyleBackColor = true;
            // 
            // checkBoxAShift
            // 
            this.checkBoxAShift.AutoSize = true;
            this.checkBoxAShift.Location = new System.Drawing.Point(9, 79);
            this.checkBoxAShift.Name = "checkBoxAShift";
            this.checkBoxAShift.Size = new System.Drawing.Size(57, 21);
            this.checkBoxAShift.TabIndex = 1;
            this.checkBoxAShift.Text = "Shift";
            this.checkBoxAShift.UseVisualStyleBackColor = true;
            // 
            // checkBoxAAlt
            // 
            this.checkBoxAAlt.AutoSize = true;
            this.checkBoxAAlt.Location = new System.Drawing.Point(9, 56);
            this.checkBoxAAlt.Name = "checkBoxAAlt";
            this.checkBoxAAlt.Size = new System.Drawing.Size(45, 21);
            this.checkBoxAAlt.TabIndex = 0;
            this.checkBoxAAlt.Text = "Alt";
            this.checkBoxAAlt.UseVisualStyleBackColor = true;
            // 
            // groupBoxMove
            // 
            this.groupBoxMove.Controls.Add(this.label7);
            this.groupBoxMove.Controls.Add(this.numericUpDownmStep);
            this.groupBoxMove.Controls.Add(this.checkBoxMEnabled);
            this.groupBoxMove.Controls.Add(this.label5);
            this.groupBoxMove.Controls.Add(this.label6);
            this.groupBoxMove.Controls.Add(this.checkBoxMCtrl);
            this.groupBoxMove.Controls.Add(this.checkBoxMShift);
            this.groupBoxMove.Controls.Add(this.checkBoxMAlt);
            this.groupBoxMove.Location = new System.Drawing.Point(204, 134);
            this.groupBoxMove.Name = "groupBoxMove";
            this.groupBoxMove.Size = new System.Drawing.Size(188, 196);
            this.groupBoxMove.TabIndex = 1;
            this.groupBoxMove.TabStop = false;
            this.groupBoxMove.Text = "Windows Move";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "Step:";
            // 
            // numericUpDownmStep
            // 
            this.numericUpDownmStep.Location = new System.Drawing.Point(57, 156);
            this.numericUpDownmStep.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownmStep.Name = "numericUpDownmStep";
            this.numericUpDownmStep.Size = new System.Drawing.Size(50, 24);
            this.numericUpDownmStep.TabIndex = 6;
            this.numericUpDownmStep.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // checkBoxMEnabled
            // 
            this.checkBoxMEnabled.AutoSize = true;
            this.checkBoxMEnabled.Location = new System.Drawing.Point(9, 20);
            this.checkBoxMEnabled.Name = "checkBoxMEnabled";
            this.checkBoxMEnabled.Size = new System.Drawing.Size(78, 21);
            this.checkBoxMEnabled.TabIndex = 5;
            this.checkBoxMEnabled.Text = "Enabled";
            this.checkBoxMEnabled.UseVisualStyleBackColor = true;
            this.checkBoxMEnabled.CheckedChanged += new System.EventHandler(this.checkBoxMEnabled_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(179, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "+ (Up | Down | Right | Left)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 17);
            this.label6.TabIndex = 3;
            this.label6.Text = "Windows Key + ";
            // 
            // checkBoxMCtrl
            // 
            this.checkBoxMCtrl.AutoSize = true;
            this.checkBoxMCtrl.Location = new System.Drawing.Point(9, 102);
            this.checkBoxMCtrl.Name = "checkBoxMCtrl";
            this.checkBoxMCtrl.Size = new System.Drawing.Size(51, 21);
            this.checkBoxMCtrl.TabIndex = 2;
            this.checkBoxMCtrl.Text = "Ctrl";
            this.checkBoxMCtrl.UseVisualStyleBackColor = true;
            // 
            // checkBoxMShift
            // 
            this.checkBoxMShift.AutoSize = true;
            this.checkBoxMShift.Location = new System.Drawing.Point(9, 79);
            this.checkBoxMShift.Name = "checkBoxMShift";
            this.checkBoxMShift.Size = new System.Drawing.Size(57, 21);
            this.checkBoxMShift.TabIndex = 1;
            this.checkBoxMShift.Text = "Shift";
            this.checkBoxMShift.UseVisualStyleBackColor = true;
            // 
            // checkBoxMAlt
            // 
            this.checkBoxMAlt.AutoSize = true;
            this.checkBoxMAlt.Location = new System.Drawing.Point(9, 56);
            this.checkBoxMAlt.Name = "checkBoxMAlt";
            this.checkBoxMAlt.Size = new System.Drawing.Size(45, 21);
            this.checkBoxMAlt.TabIndex = 0;
            this.checkBoxMAlt.Text = "Alt";
            this.checkBoxMAlt.UseVisualStyleBackColor = true;
            // 
            // windowsMaximizeGroupBox
            // 
            this.windowsMaximizeGroupBox.Controls.Add(this.initialMaximizeHeightTextBox);
            this.windowsMaximizeGroupBox.Controls.Add(this.maximizeSizeSeparatorLabel);
            this.windowsMaximizeGroupBox.Controls.Add(this.initialMaximizeWidthTextBox);
            this.windowsMaximizeGroupBox.Controls.Add(this.initialSizeLabel);
            this.windowsMaximizeGroupBox.Controls.Add(this.enableDoubleMaximizeCheckBox);
            this.windowsMaximizeGroupBox.Location = new System.Drawing.Point(399, 134);
            this.windowsMaximizeGroupBox.Name = "windowsMaximizeGroupBox";
            this.windowsMaximizeGroupBox.Size = new System.Drawing.Size(186, 196);
            this.windowsMaximizeGroupBox.TabIndex = 2;
            this.windowsMaximizeGroupBox.TabStop = false;
            this.windowsMaximizeGroupBox.Text = "Windows Maximize";
            // 
            // initialMaximizeHeightTextBox
            // 
            this.initialMaximizeHeightTextBox.Location = new System.Drawing.Point(90, 64);
            this.initialMaximizeHeightTextBox.MaxLength = 4;
            this.initialMaximizeHeightTextBox.Name = "initialMaximizeHeightTextBox";
            this.initialMaximizeHeightTextBox.Size = new System.Drawing.Size(50, 24);
            this.initialMaximizeHeightTextBox.TabIndex = 4;
            this.initialMaximizeHeightTextBox.Text = "1024";
            // 
            // maximizeSizeSeparatorLabel
            // 
            this.maximizeSizeSeparatorLabel.AutoSize = true;
            this.maximizeSizeSeparatorLabel.Location = new System.Drawing.Point(69, 67);
            this.maximizeSizeSeparatorLabel.Name = "maximizeSizeSeparatorLabel";
            this.maximizeSizeSeparatorLabel.Size = new System.Drawing.Size(16, 17);
            this.maximizeSizeSeparatorLabel.TabIndex = 3;
            this.maximizeSizeSeparatorLabel.Text = "x";
            // 
            // initialMaximizeWidthTextBox
            // 
            this.initialMaximizeWidthTextBox.Location = new System.Drawing.Point(13, 64);
            this.initialMaximizeWidthTextBox.MaxLength = 4;
            this.initialMaximizeWidthTextBox.Name = "initialMaximizeWidthTextBox";
            this.initialMaximizeWidthTextBox.Size = new System.Drawing.Size(50, 24);
            this.initialMaximizeWidthTextBox.TabIndex = 2;
            this.initialMaximizeWidthTextBox.Text = "1280";
            // 
            // initialSizeLabel
            // 
            this.initialSizeLabel.AutoSize = true;
            this.initialSizeLabel.Location = new System.Drawing.Point(10, 44);
            this.initialSizeLabel.Name = "initialSizeLabel";
            this.initialSizeLabel.Size = new System.Drawing.Size(68, 17);
            this.initialSizeLabel.TabIndex = 1;
            this.initialSizeLabel.Text = "Initial size:";
            // 
            // enableDoubleMaximizeCheckBox
            // 
            this.enableDoubleMaximizeCheckBox.AutoSize = true;
            this.enableDoubleMaximizeCheckBox.Location = new System.Drawing.Point(11, 20);
            this.enableDoubleMaximizeCheckBox.Name = "enableDoubleMaximizeCheckBox";
            this.enableDoubleMaximizeCheckBox.Size = new System.Drawing.Size(175, 21);
            this.enableDoubleMaximizeCheckBox.TabIndex = 0;
            this.enableDoubleMaximizeCheckBox.Text = "Enable Double Maximize";
            this.enableDoubleMaximizeCheckBox.UseVisualStyleBackColor = true;
            this.enableDoubleMaximizeCheckBox.CheckedChanged += new System.EventHandler(this.enableDoubleMaximizeCheckBox_CheckedChanged);
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 376);
            this.Controls.Add(this.windowsMaximizeGroupBox);
            this.Controls.Add(this.groupBoxMove);
            this.Controls.Add(this.groupBoxAttached);
            this.Controls.Add(this.groupBox);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(290, 193);
            this.Name = "Form";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Keys Extender (Win 7 Compatible)";
            this.contextMenuStrip.ResumeLayout(false);
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBoxAttached.ResumeLayout(false);
            this.groupBoxAttached.PerformLayout();
            this.groupBoxMove.ResumeLayout(false);
            this.groupBoxMove.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownmStep)).EndInit();
            this.windowsMaximizeGroupBox.ResumeLayout(false);
            this.windowsMaximizeGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.NotifyIcon notifyIcon;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel linkMail;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ToolStripMenuItem showToolStripMenuItem;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.GroupBox groupBoxAttached;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBoxACtrl;
        private System.Windows.Forms.CheckBox checkBoxAShift;
        private System.Windows.Forms.CheckBox checkBoxAAlt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBoxAEnabled;
        private System.Windows.Forms.GroupBox groupBoxMove;
        private System.Windows.Forms.CheckBox checkBoxMEnabled;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox checkBoxMCtrl;
        private System.Windows.Forms.CheckBox checkBoxMShift;
        private System.Windows.Forms.CheckBox checkBoxMAlt;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numericUpDownmStep;
        private System.Windows.Forms.GroupBox windowsMaximizeGroupBox;
        private System.Windows.Forms.CheckBox enableDoubleMaximizeCheckBox;
        private System.Windows.Forms.TextBox initialMaximizeHeightTextBox;
        private System.Windows.Forms.Label maximizeSizeSeparatorLabel;
        private System.Windows.Forms.TextBox initialMaximizeWidthTextBox;
        private System.Windows.Forms.Label initialSizeLabel;
    }
}