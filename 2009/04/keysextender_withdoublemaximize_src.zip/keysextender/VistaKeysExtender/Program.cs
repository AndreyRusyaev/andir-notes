﻿using System.Windows.Forms;
using VistaKeysExtender.Properties;

namespace VistaKeysExtender
{
    static class Program
    {
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form(Settings.Default.ShowNotifyIcon));
        }
    }
}
