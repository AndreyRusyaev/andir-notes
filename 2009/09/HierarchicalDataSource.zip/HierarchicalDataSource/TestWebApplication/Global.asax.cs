﻿using System;

namespace Home.Andir.Examples
{
    public class Global : System.Web.HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            AppDomain.CurrentDomain.SetData(
                "SQLServerCompactEditionUnderWebHosting", 
                true);
        }
    }
}