﻿using System;

using Home.Andir.Examples.Code.DataLayer;

namespace Home.Andir.Examples
{
    public partial class TreeViewWithRepositoryPage 
        : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var repository = new DepartmentRepository();

            treeView.DataSource =
                new GenericHierarchicalDataSource<Department>(
                    new PlainTreeModelRepository<Department>(
                        () => repository.GetDepartments(),
                        parentID => repository.GetDepartments(parentID),
                        id => repository.GetDepartment(id)));
            treeView.DataBind();
        }
    }
}
