﻿using System;
using System.ComponentModel;

namespace Home.Andir.Examples
{
    internal static class TypeDescriptorExtensions
    {
        public static TResult GetProperty<TResult>(
            this object item,
            string propName)
        {
            var properties = TypeDescriptor.GetProperties(item);
            var descriptor = properties.Find(propName, true);
            if (descriptor != null
                && descriptor.PropertyType == typeof(TResult))
            {
                return (TResult)descriptor.GetValue(item);
            }
            else
            {
                throw new InvalidOperationException(
                    String.Format("Property '{0}' with type '{1}' not found.", 
                        propName, typeof(TResult)));
            }
        }

        public static void CheckPropertiesExist(
            this Type type,
            params string[] propertyNames)
        {
            var properties = TypeDescriptor.GetProperties(type);
            foreach (var propertyName in propertyNames)
            {
                var descriptor = properties.Find(propertyName, true);
                if (descriptor == null)
                    throw new ApplicationException(
                        String.Format("Property '{0}' not found.", 
                            propertyName));
            }
        }
    }
}
