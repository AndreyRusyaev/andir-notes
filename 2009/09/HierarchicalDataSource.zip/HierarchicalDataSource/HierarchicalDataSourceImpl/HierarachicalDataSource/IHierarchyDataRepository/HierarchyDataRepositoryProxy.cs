﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Home.Andir.Examples
{
    public sealed class HierarchyDataRepositoryProxy<T>
        : IHierarchyDataRepository<T> 
        where T : class
    {
        readonly Func<IEnumerable<T>> getRootsImpl;
        readonly Func<T, IEnumerable<T>> getChildrenImpl;
        readonly Func<T, T> getParentImpl;
        readonly Func<string, T> getItemImpl;
        readonly Func<string, T, string> getPathImpl;
        readonly Func<T, string> getItemTypeImpl;

        public HierarchyDataRepositoryProxy(
            Func<IEnumerable<T>> getRoots,
            Func<T, IEnumerable<T>> getChildren,
            Func<T, T> getParent,
            Func<string, T> getItemImpl,
            Func<string, T, string> getPath,
            Func<T, string> getItemType
            )
        {
            if (getRoots == null)
                throw new ArgumentNullException("getRoots");

            this.getRootsImpl = getRoots;
            this.getChildrenImpl = getChildren;
            this.getParentImpl = getParent;
            this.getItemImpl = getItemImpl;
            this.getPathImpl = getPath;
            this.getItemTypeImpl = getItemType;
        }

        #region IHierarchyDataAdapter<T> Members

        public T GetParent(T item)
        {
            if (item == null)
                throw new ArgumentNullException("item");

            return getParentImpl(item);
        }

        public IEnumerable<T> GetChildren(T item)
        {
            if (item == null)
                return getRootsImpl();

            return getChildrenImpl(item);
        }

        public T GetItem(string path)
        {
            if (path == null)
                throw new ArgumentNullException("path");

            return getItemImpl(path);
        }

        public string GetItemHierarchyPath(string parentPath, T item)
        {
            if (parentPath == null)
                throw new ArgumentNullException("parentPath");
            if (item == null)
                throw new ArgumentNullException("item");

            return getPathImpl(parentPath, item);
        }

        public string GetItemType(T item)
        {
            if (item == null)
                throw new ArgumentNullException("item");

            return getItemTypeImpl(item);
        }

        #endregion
    }
}
