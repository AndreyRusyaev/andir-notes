﻿using System.Web.UI;

namespace Home.Andir.Examples
{
    public abstract class HierarchyData<T> : IHierarchyData
    {
        public abstract HierarchyData<T> GetParent();
        public abstract HierarchicalEnumerable<T> GetChildren();
        public abstract T Item { get; }
        
        #region IHierarchyData Members

        IHierarchyData IHierarchyData.GetParent()
        {
            return GetParent();
        }

        public abstract bool HasChildren { get; }

        IHierarchicalEnumerable IHierarchyData.GetChildren()
        {
            return GetChildren();
        }

        object IHierarchyData.Item
        {
            get { return Item; }
        }

        public abstract string Path { get; }
        public abstract string Type { get; }

        #endregion
    }
}
