﻿using System.Collections.Generic;

namespace Home.Andir.Examples.Code.Model
{
    public class ORMTreeModel
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public ORMTreeModel Parent { get; set; }
        public IEnumerable<ORMTreeModel> Children { get; set; }
    }
}
