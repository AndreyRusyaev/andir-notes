﻿
namespace Home.Andir.Examples
{
    public class PlainTreeModel
    {
        public int ID { get; set; }
        public int? ParentID { get; set; }

        public string Name { get; set; }
    }
}
