﻿using System;
using System.Collections.Generic;

namespace Home.Andir.Examples
{
    public class PlainTreeModelRepository<T>
        : IHierarchyDataRepository<T> 
        where T : class
    {
        readonly Func<IEnumerable<T>> getRootsImpl;
        readonly Func<int, IEnumerable<T>> getItemsById;
        readonly Func<int, T> getItemByIdImpl;

        public PlainTreeModelRepository(
            IPlainTreeModelRepository<T> repository)
            :this(repository.GetRoots, repository.GetItems, repository.GetItem)
        { }

        public PlainTreeModelRepository(
            Func<IEnumerable<T>> getRootsImpl,
            Func<int, IEnumerable<T>> getItemsById,
            Func<int, T> getItemByIdImpl)
        {
            this.getRootsImpl = getRootsImpl;
            this.getItemsById = getItemsById;
            this.getItemByIdImpl = getItemByIdImpl;

            typeof(T).CheckPropertiesExist(
                "ID", "ParentID");
        }

        public T GetItem(string path)
        {
            var pathItems = path.Split('/');
            if (pathItems.Length > 0)
            {
                int itemID = int.Parse(
                    pathItems[pathItems.Length - 1]);
                return getItemByIdImpl(itemID);
            }

            return null;
        }

        public IEnumerable<T> GetChildren(T item)
        {
            if (item == null)
                return getRootsImpl();

            return getItemsById(
                item.GetProperty<int>("ID")
                );
        }

        public T GetParent(T item)
        {
            if (item == null)
                throw new ArgumentNullException("item");

            var parentID = item.GetProperty<int>("ParentID");

            return getItemByIdImpl(parentID);
        }

        public string GetItemHierarchyPath(
            string parentHierarchyPath, T item)
        {
            if (parentHierarchyPath == null)
                throw new ArgumentNullException("parentHierarchyPath");
            if (item == null)
                throw new ArgumentNullException("item");

            return string.Format("{0}/{1}",
                parentHierarchyPath,
                item.GetProperty<int>("ID"));
        }

        public string GetItemType(T item)
        {
            if (item == null)
                throw new ArgumentNullException("item");

            return typeof(T).ToString();
        }
    }
}
