﻿using System;
using System.Collections.Generic;

namespace Home.Andir.Examples
{
    public class ORMTreeModelRepository<T>
        : IHierarchyDataRepository<T> 
        where T : class
    {
        readonly Func<IEnumerable<T>> getRootsImpl;
        readonly Func<int, T> getItemByIdImpl;

        public ORMTreeModelRepository(
            IORMTreeModelRepository<T> repository)
            : this(repository.GetRoots, repository.GetItem)
        { }

        public ORMTreeModelRepository(
            Func<IEnumerable<T>> getRootsImpl,
            Func<int, T> getItemImpl)
        {
            this.getRootsImpl = getRootsImpl;
            this.getItemByIdImpl = getItemImpl;

            typeof(T).CheckPropertiesExist(
                "ID", "Parent", "Children");
        }

        public T GetItem(string path)
        {
            var pathItems = path.Split('/');
            if (pathItems.Length > 0)
            {
                int itemID = int.Parse(
                    pathItems[pathItems.Length - 1]);
                return getItemByIdImpl(itemID);
            }

            return null;
        }

        public IEnumerable<T> GetChildren(T item)
        {
            if (item == null)
                return getRootsImpl();

            return item.GetProperty<IEnumerable<T>>("Children");
        }

        public T GetParent(T item)
        {
            if (item == null)
                throw new ArgumentNullException("item");

            return item.GetProperty<T>("Parent");
        }

        public string GetItemHierarchyPath(
            string parentHierarchyPath, T item)
        {
            if (parentHierarchyPath == null)
                throw new ArgumentNullException("parentHierarchyPath");
            if (item == null)
                throw new ArgumentNullException("item");

            return string.Format("{0}/{1}",
                parentHierarchyPath,
                item.GetProperty<int>("ID"));
        }

        public string GetItemType(T item)
        {
            if (item == null)
                throw new ArgumentNullException("item");

            return typeof(T).ToString();
        }
    }
}
