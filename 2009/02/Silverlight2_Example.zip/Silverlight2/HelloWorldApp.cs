﻿using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Markup;

public class HelloWorldApp : Application
{
	public HelloWorldApp()
	{
		this.Startup += this.Application_Startup;
	}

	private void Application_Startup(object sender, StartupEventArgs e)
	{
		RootVisual = (UIElement)XamlReader.Load(
			GetResource("HelloWorld.xaml"));
	}

	private string GetResource(string resourceName)
	{
		var assembly = Assembly.GetExecutingAssembly();
		using (var reader = new StreamReader(
			  assembly.GetManifestResourceStream(resourceName)
			  ))
		{
			return reader.ReadToEnd();
		}
	}
}