﻿using System;
using System.Web.UI.Design;

namespace Home.Andir.Examples
{
    public class HashItExpressionEditor : ExpressionEditor
    {
        public override object EvaluateExpression(
            string expression,
            object parseTimeData,
            Type propertyType,
            IServiceProvider serviceProvider)
        {
            return HashItEvaluator.Eval(expression);
        }

        public override ExpressionEditorSheet GetExpressionEditorSheet(
            string expression, 
            IServiceProvider serviceProvider)
        {
            return new HashItExpressionEditorSheet(expression, serviceProvider);
        }
    }
}
