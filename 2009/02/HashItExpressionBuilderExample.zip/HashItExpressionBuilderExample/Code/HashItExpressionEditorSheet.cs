﻿using System;
using System.ComponentModel;
using System.Web.UI.Design;

namespace Home.Andir.Examples
{
    public class HashItExpressionEditorSheet : ExpressionEditorSheet
    {
        public HashItExpressionEditorSheet(
            string expression,
            IServiceProvider serviceProvider
            ) : base(serviceProvider)
        {
            var parseResults = HashItEvaluator.ParseExpression(expression);
            if (parseResults != null)
            {
                HashAlg = parseResults.HashAlg;
                EncodeType = parseResults.EncodeType;
                Source = parseResults.Source;
            }
        }

        [DefaultValue(HashAlg.MD5), DisplayName("Hash algorithm")]
        public HashAlg HashAlg { get; set; }
        [DefaultValue(EncodeType.Hex), DisplayName("Result encoding")]
        public EncodeType EncodeType { get; set; }
        [DefaultValue(""), DisplayName("Some text")]
        public string Source { get; set; }

        public override bool IsValid
        {
            get { return true; }
        }

        public override string GetExpression()
        {
            var result = String.Format("{0}('{1}')", HashAlg.ToString(), Source);

            if (EncodeType == EncodeType.Base64)
                result += ": Base64";

            return result;
        }
    }
}
