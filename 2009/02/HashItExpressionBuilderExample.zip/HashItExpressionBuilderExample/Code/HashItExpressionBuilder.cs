﻿using System.CodeDom;
using System.Web.Compilation;
using System.Web.UI;

namespace Home.Andir.Examples
{
    [ExpressionEditor(typeof(HashItExpressionEditor))]
    public class HashItExpressionBuilder : ExpressionBuilder
    {
        public override CodeExpression GetCodeExpression(
            BoundPropertyEntry entry, 
            object parsedData,
            ExpressionBuilderContext context)
        {
            return new CodePrimitiveExpression(
                HashItEvaluator.Eval(entry.Expression));
        }
    }
}
