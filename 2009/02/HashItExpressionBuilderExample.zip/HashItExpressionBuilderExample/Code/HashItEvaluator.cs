﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace Home.Andir.Examples
{
    public enum HashAlg
    {
        MD5,
        SHA1,
        SHA256,
        SHA512
    }

    public enum EncodeType
    {
        Base64,
        Hex
    }

    public static class HashItEvaluator
    {
        public class HashItParseResults
        {
            public HashAlg HashAlg { get; set; }
            public string Source { get; set; }
            public EncodeType EncodeType { get; set; }
        }

        public static string Eval(string expression)
        {
            var parseResults = ParseExpression(expression);
            if (parseResults != null)
            {
                return Eval(parseResults);
            }

            return "Invalid expression";
        }

        private static string Eval(HashItParseResults parseResults)
        {
            HashAlgorithm hash = CreateAlgorithm(parseResults.HashAlg);

            var result = hash.ComputeHash(
                Encoding.Default.GetBytes(parseResults.Source));

            if (parseResults.EncodeType == EncodeType.Hex)
            {
                return String.Concat(
                    result.Select(x => String.Format("{0:x2}", x)).ToArray()
                    );
            }

            return Convert.ToBase64String(result);
        }

        private static HashAlgorithm CreateAlgorithm(HashAlg alg)
        {
            switch (alg)
            {
                case HashAlg.MD5: return MD5.Create();
                case HashAlg.SHA1: return new SHA1Managed();
                case HashAlg.SHA256: return new SHA256Managed();
                case HashAlg.SHA512: return new SHA512Managed();
            }

            throw new ArgumentOutOfRangeException("alg");
        }

        public static HashItParseResults ParseExpression(string expression)
        {
            // expression == MD5(source) [: Base64]
            Regex expRe = new Regex(
                @"(?<alg>MD5|SHA1|SHA256|SHA512)\('(?<source>.+)'\)(\s*:\s*(?<enc>(Base64|Hex)))?",
                RegexOptions.IgnoreCase
                );

            var match = expRe.Match(expression);

            if (match != null)
            {
                string alg = match.Groups["alg"].Value;
                string source = match.Groups["source"].Value;
                string enc = match.Groups["enc"].Value;

                return new HashItParseResults()
                {
                    HashAlg = (HashAlg)Enum.Parse(typeof(HashAlg), alg, true),
                    Source = source,
                    EncodeType = enc.ToUpper() == "BASE64" ? EncodeType.Base64 : EncodeType.Hex
                };
            }

            return null;
        }
    }
}
